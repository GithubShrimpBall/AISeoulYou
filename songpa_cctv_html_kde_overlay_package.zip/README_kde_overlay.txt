송파구 CCTV 지도 + 20m 역-KDE 오버레이 사용법

1) 이 HTML 파일과 Colab에서 만든 PNG 파일을 같은 폴더에 둡니다.
   - songpa_cctv_interactive_map_with_kde_overlay.html
   - reverse_kde_20m_web.png

2) HTML을 브라우저로 엽니다.

3) 우측 상단 레이어 버튼에서 다음 레이어를 켜고 끌 수 있습니다.
   - CCTV 위치 마커
   - 기존 카메라 대수 히트맵
   - 20m 역-KDE 취약도

적용된 KDE PNG bounds:
[[37.46822524997722, 127.06931105293643], [37.54087034993445, 127.16224377953077]]

주의: reverse_kde_20m_web.png가 같은 폴더에 없으면 KDE 오버레이는 표시되지 않습니다.
